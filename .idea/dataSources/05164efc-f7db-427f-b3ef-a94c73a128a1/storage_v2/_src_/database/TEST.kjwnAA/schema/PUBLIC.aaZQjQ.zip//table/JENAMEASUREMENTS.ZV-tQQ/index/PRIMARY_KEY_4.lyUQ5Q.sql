create unique index PRIMARY_KEY_4
    on JENAMEASUREMENTS (ID);

